<?php
@session_start(); 
include("../enlace/conexion.php");
$id_usu=(int)@$_SESSION['id_usuario'];
$tipoUz=(int)$_SESSION['tipo_U'];
$mifoto=@$_SESSION['img_foto'];
$minombre2=$_SESSION['nombre_usu'];
$mifoto="0.png";
//echo "idUsuario: ".$id_usu."- Tipo de Usuario: ".$tipoUz;
if(($id_usu!=0)&&($tipoUz!=0)){
?> 
<script languaje="JavaScript">
location.href='../index.html';
</script>

<?php
}else{
    // Se ejecuta el ajax normalmente  
	if (!$conexion) {

		echo "La conexion no se pudo realizar, consulte con su administrador del sistema.";

		//exit;

	}

  
?>



<!DOCTYPE html>
<html lang="en">
<head>
<link rel="icon" type="image/png" href="imag/icon2.png" />
<title>TKD Bolivar -DAM21</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
<!---------------MEnu-------------------------------->
<style>
@import url(https://fonts.googleapis.com/css?family=Roboto);
html, body {
  height: 100%;
  
}

body {
	background-image: url("../img/head4.png");
	background-repeat:no-repeat;
  
}

nav {
  max-width: 75%;
  mask-image: linear-gradient(90deg, rgba(255, 255, 255, 0) 0%, #ffffff 25%, #ffffff 75%, rgba(255, 255, 255, 0) 100%);
  margin: 0 auto;
  padding: 75px 0;
}

nav ul {
  text-align: center;
  background: linear-gradient(90deg, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.2) 25%, rgba(255, 255, 255, 0.2) 75%, rgba(255, 255, 255, 0) 100%);
  width: 100%;
  box-shadow: 0 0 25px rgba(0, 0, 0, 0.1), inset 0 0 1px rgba(255, 255, 255, 0.6);
}

nav ul li {
  display: inline-block;
}

nav ul li a {
  padding: 20px;
  font-family: "Roboto";
  color: rgba(0, 0, 0, 0.5);
  text-shadow: 1px 1px 1px rgba(255, 255, 255, 0.4);
  font-size: 15px;
  text-decoration: none;
  display: block;
  cursor:pointer;
}

nav ul li a:hover {
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1), inset 0 0 1px rgba(255, 255, 255, 0.6);
  background: rgba(255, 255, 255, 0.1);
  color: rgba(0, 0, 0, 0.7);
}
</style>

<script>

</script>
<!---------------Librerias-------------------------------->
<script src='libros/libPeal.js' type='text/javascript'/></script>
<script src='libros/validPeal.js' type='text/javascript'/></script>
<script type="text/javascript" src="libros/js/jquery.js"></script>
<script type="text/javascript" src="libros/jquery.js"></script>
<script type="text/javascript" src="libros/jquery.watermarkinput.js"></script>
<!----Lib Finana----->
<script type="text/javascript" src="libros/libFinan/FunFinan.js"></script>
<!-------->
<script type="text/javascript" src="libros/jfind.js"></script>
<script type="text/javascript" src="libros/jlock.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

<!----------------------------------------------------------------->
 

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>



<!--------------------PHOTO----------------------------------->
<script type="text/javascript" src="libros/jquery.min.js"></script>
<script type="text/javascript" src="libros/jquery.form.js"></script>
<script type="text/javascript" >
 $(document).ready(function() { 
		
            $('#photoimg').live('change', function()			{ 
			           $("#preview").html('');
			    $("#preview").html('<img src="sub_img/loader.gif" alt="Cargando...."/>');
			$("#imageform").ajaxForm({
						target: '#preview'
		}).submit();
		
			});
        }); 
</script>

<script type="text/javascript" >
 $(document).ready(function() { 
		
            $('#photoimg').live('change', function()			{ 
			           $("#nombreF").html('');
			    
			//$("#imageform").ajaxForm({
				//		target: '#nombreF'
		//}).submit();
		
			});
        }); 
</script>
<!-------------------------------------------------------->

<!-----------------------------------HOJAS DE ESTILO-------------------------------->
<link href="ccss/piel_dam.css" rel="stylesheet" type="text/css" />
<!----------------------------------------------------------------------------------->
<style>
.button {
  border: none;
  outline: none;
  height: 30px;
  background: #b80f22;
  color: #fff;
  font-size: 18px;
  border-radius: 5px;
  width:100%;
  font-weight:bolder;
}


.button:hover {
  cursor: pointer;
  background: #ffc107;
  color: #000;
}
</style>

</head>
<body  >
	 <!-------Encabezado ------>
     <div style="vertical-align:top; ">
    <img src="../img/banerliga_new.png" width="600" height="110"  />
</div>

 <!--------------->
 <div style="float:left;  display:block;  ">
 <table width="329"><tr> <td width="17" rowspan="2" valign="middle"><?php echo "<img src=sub_img/uploads/".$mifoto."  width='60 height='60' />";?></td>
 <td colspan="3" align="justify"  style="font:Verdana; color:#111111; text-align:justify; font-size:14px; font-weight:bold; ">Administrador Liga</td>
 
</tr><tr><td align="left" width="36" ><div  class="button"><a   onClick="if(confirm('Deseas cerrar la sesión actual?')){window.location='cerrarsesion.php';}"><img style="vertical-align:middle" src="imag/menu/cerrar.png" alt="" width="30" height="30" /> Salir</a></div></td>
<td width="2"></td><td width="254" align="right"><div id="carga" style="visibility:hidden; "><img style="vertical-align:middle; text-align:right;" src="imag/espera.gif" alt="" width="90" height="22" /></div></td></tr>
<tr> <td colspan="3"></td>
</tr>
</table></div>

 </div>
<p></p>
<p></p>
<p></p>
 <!--inicio barra de  menu -->
    
    
    
<nav>
  <ul>
<li><a onClick="grupoFocus('plan.php','DivContenido','carga','','limpio.html','opciones');">Inicio</a></li> 

<li><a onClick="grupoFocus('nucleo/registro/scrin/reg_directo.php','DivContenido','carga','','limpio.html','opciones');" title="Deportistas Nuevos" >Registro de deportistas</a></li>

<li><a onClick="grupoFocus('nucleo/consultas/scrin/consulta_dep.php','DivContenido','carga','','limpio.html','opciones');" title="Eliminar Horas y Fechas" >Consultar Dep.</a></li>

<li><a onClick="cargarFocus('nucleo/registro/scrin/x_club.php','opciones','carga','');" title="Registro de entidad deportiva" >Clubes</a></li>
<li><a onClick="cargarFocus('nucleo/registro/scrin/Nevento.php','DivContenido','carga','');" title="Configurar Tests"  >Crear Evento</a></li> 

<li><a onClick="grupoFocus('nucleo/consultas/scrin/consultas.php','DivContenido','carga','','limpio.html','opciones');" title="Configurar Tests"  >Consultas</a></li> 

<li><a onClick="grupoFocus('nucleo/consultas/scrin/consulta_dep.php','DivContenido','carga','','limpio.html','opciones');" title="Configurar Tests"  >
Lista Ranking</a></li> 

 </ul>
</nav>
<!------------------------------------>
<div id="opciones" style=" float:right; vertical-align:top; height:50px; width:98%; display:block; float:right; margin-right:10px; margin-bottom:10px; padding-top:10px; padding-bottom:20px"></div>
<!---------------->
<div   id="DivContenido" style=" float:right; vertical-align:top; height:1500px; width:98%; display:block; float:right; margin-right:10px; padding-top:10px" >


</div>

</body>
</head>
<?php
}
?>