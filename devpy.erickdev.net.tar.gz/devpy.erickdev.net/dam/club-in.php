<?PHP
session_start(); 
include("../enlace/conexion.php"); 
$id_usu=(int)@$_SESSION['id_usuario'];
$tipoUz=(int)$_SESSION['tipo_U'];
$mifoto=@$_SESSION['img_foto'];
$minombre2=$_SESSION['nombre_usu'];




//$mifoto="0.png";


$Xrefer = getenv('HTTP_REFERER'); 
if ((!$Xrefer) || ($id_usu==0)){
?> 
<script languaje="JavaScript">
location.href='../sesionOut.html';
</script>

<?php
}else{
    // Se ejecuta el ajax normalmente  
 
?>  
<?php  




	

	if (!$conexion) {

		echo "La conexion no se pudo realizar, consulte con su administrador del sistema.";

		//exit;

	}
/////////////////////////////////////////////////////
//$mifoto=@$_SESSION['img_foto'];
//$minombre2=$_SESSION['nombre_usu'];
  
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="icon" type="image/png" href="imag/icon2.png" />
<title>COLOSO TKD -DAM21</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
<!---------------MEnu-------------------------------->

<script>

</script>
<!---------------Librerias-------------------------------->
<script src='libros/libDam.js' type='text/javascript'/></script>
<script src='libros/validDam.js' type='text/javascript'/></script>
<script type="text/javascript" src="libros/js/jquery.js"></script>
<script type="text/javascript" src="libros/jquery.js"></script>
<script type="text/javascript" src="libros/jquery.watermarkinput.js"></script>
<!----Lib Finana----->
<script type="text/javascript" src="libros/libFinan/FunFinan.js"></script>
<!-------->
<script type="text/javascript" src="libros/jfind.js"></script>
<script type="text/javascript" src="libros/jlock.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

<!----------------------------------------------------------------->
 
<!----------------------fecha------------------------------->


<link rel="stylesheet" type="text/css" href="faces/datedropper.css"> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="libros/datedropper.js"></script>
<script>
$(document).ready(function(){
    $("#from").dateDropper();
});
</script>


<!-----------------------------------HOJAS DE ESTILO-------------------------------->

<link href="ccss/apariencia2.css" rel="stylesheet" type="text/css"/>
<link href="ccss/estilo2.css" rel="stylesheet" type="text/css" />


 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!----------------------------------------------------------------------------------->
 <!-- Bootstrap core CSS -->
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<!----------------------------------------------------------------->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<!--------------------------------------------------->
 <!----------------------------------------------------------------->

<script>
function habilita() {
	// Accedemos al botón
var txtAcu = document.getElementById('txtAcudiente');
var txtDoc = document.getElementById('txtDocumento2');
var txtTipo = document.getElementById('TipoDocumento2');
// evento para el input radio del "no"
  txtAcu.disabled = false;
  txtTipo.disabled=false;
  txtDoc.disabled=false;
  txtAcu.value="";
  txtTipo.value="";
  txtDoc.value="";
  txtAcu.focus();
}
function nohabilita() {
	// Accedemos al botón
var txtAcu = document.getElementById('txtAcudiente');
var txtDoc = document.getElementById('txtDocumento2');
var txtTipo = document.getElementById('TipoDocumento2');

// evento para el input radio del "si"

  txtAcu.disabled = true;
  txtTipo.disabled=true;
  txtDoc.disabled=true;
  txtAcu.value="Yo Mismo";
  txtTipo.value=document.getElementById('TipoDocumento').value;
  txtDoc.value=document.getElementById('txtDocumento').value;
  document.getElementById('txtCelular').focus();



    
}
</script>
<style>

body
{
font-family:arial;
}
.preview
{
width:200px;
border:solid 1px #dedede;
padding:10px;
}
#preview
{
color:#cc0000;
font-size:12px
}

</style>
 <!---------------foto-------------------->
  
<script type="text/javascript" src="libros/jquery.min.js"></script>
<script type="text/javascript" src="libros/jquery.form.js"></script>

<script type="text/javascript" >
 $(document).ready(function() { 
		
            $('#photoimg').live('change', function()			{ 
			           $("#preview").html('');
			    $("#preview").html('<img src="sub_img/loader.gif" alt="Cargando...."/>');
			$("#imageform").ajaxForm({
						target: '#preview'
		}).submit();
				});
        }); 
</script>

<script type="text/javascript" >
 $(document).ready(function() { 
		
            $('#photoimg').live('change', function()			{ 
			           $("#nombreF").html('');
			    
			//$("#imageform").ajaxForm({
				//		target: '#nombreF'
		//}).submit();
		
			});
        }); 
</script>
<script> 
function ejecutaEventoOnclick(idUsu){ 

   //alert('si fue'+idUsu);
    if((idUsu==0)){
     location.href='../sesionOut.html';

    }
     
} 
</script>
<!--------------fin foto------------------->
</head>


<body  onclick="ejecutaEventoOnclick(<?php echo $id_usu;?>);"  > 
	 <!-------Encabezado ------>
     
 <!--------------->

 <!--inicio barra de  menu -->
   

 <nav class="navbar navbar-expand-lg "style="background-color: #196a84 ;cursor: pointer; color: #ffff">
  
  <b class="navbar-brand" > <? echo $minombre2;?></b>
  
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent" >
      <ul class="navbar-nav justify-content-end ">
   
   
   
    
    <li class="nav-item">
      <a class="nav-link " aria-current="page" onClick="cargarFocus('modDam/mod_registro/scrin/m_entidad.php?idClub=<?=$id_usu?>','DivContenido','carga','');" title="Registro de entidad deportiva" > Mi Club</a>
    </li>
 <!--------------------------------------------->   
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle"  id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Socios Estudiantes
        </a>
        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
        <li class="nav-item"> 
      <a class="dropdown-item"  onClick="cargarFocus('modDam/mod_registro/scrin/reg_directo.php','DivContenido','carga','');" title="Deportistas Nuevos" > Registro de Atletas</a>
    </li>
    <li class="nav-item"> 
      <a class="dropdown-item"   onClick="cargarFocus('modDam/mod_registro/scrin/Rdep.php','DivContenido','carga','');" title="Deportistas Nuevos" > Registro Rapido de Atletas</a>
    </li>

   
          <li> <a class="dropdown-item" onClick="cargarFocus('modDam/mod_consultas/scrin/consulta_dep.php','DivContenido','carga','');" title="Configurar Tests">Actualizar Infomación</a></li>
          <li><a class="dropdown-item" >Asignar Grados</a></li>
          <li><hr class="dropdown-divider"></li>
         <li> <a class="dropdown-item" >Listados</a></li>
      </ul>
      </li>

        
 <!---------------------------------------------->   
 

     <li class="nav-item">
     <a class="nav-link " aria-current="page" onClick="cargarFocus('modDam/mod_consultas/Rpdf/scrin/carnet.php','DivContenido','carga','');" title="Generar Carnet"  > Generar Carnet</a>
    </li>
    <li class="nav-item">
     <a class="nav-link " aria-current="page" style="vertical-align:middle" onClick="cargarFocus('modDam/mod_consultas/Rpdf/scrin/consulta_gen.php','DivContenido','carga','');" title="Configurar Tests"  > Generar Listas</a>
    </li>
   <!--------------------------------------------->   
 <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle"  id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Inscribir a Eventos
        </a>
        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
          <li><a class="dropdown-item" href="#" onClick="cargarFocus('modDam/kombat/scrin/busca_dep.php','DivContenido','carga','TipoDocumento');">Combate</a></li>
  <li><a class="dropdown-item" href="#" onClick="cargarFocus('modDam/poom/scrin/busca_dep.php','DivContenido','carga','');">Poomsae</a></li>
  <li><a class="dropdown-item" href="#" onClick="cargarFocus('modDam/infantes/scrin/busca_dep.php','DivContenido','carga','Grados');">Infantil</a></li>
  <li><hr class="dropdown-divider"></li>
  <li><a class="dropdown-item" href="#" onClick="cargarFocus('modDam/mod_consultas/Rpdf/scrin/busca_planilla.php','DivContenido','carga','');">Consultas</a></li>
</ul>
      </li>

        
 <!---------------------------------------------->    
    <li>
       <button class="btn btn-outline-danger" type="button" onClick="if(confirm('Deseas cerrar la sesión actual?')){window.location='cerrarsesion.php';}">Salir</button>
                                
    </li>
  </ul>
  </div>
</nav>



  

<!---------------->
 
 

<div  id="DivContenido" class="container" style="  vertical-align:top; height:auto; width:98%; display:inline-block; margin-right:10px; padding-top:100px" >


</div>
<div id="carga" style="visibility:hidden; position:relative; "><img style="vertical-align:middle" src="imag/espera.gif" alt="" width="170" height="22" /></div>

</body>


</html>
<?php

}
?>
