<?PHP 
session_start();
$id_usu=(int)@$_SESSION['id_usuario'];
include("../../enlace/conexion.php");

if (!$conexion) {

  echo "La conexion no se pudo realizar, consulte con su administrador del sistema.";

  //exit;

}
////////////////////////////del edit////////////////////////////

$nMeses=["Sin Registros","ENERO","FEBRERO","MARZO","ABRIL","MAYO","JUNIO", "JULIO","AGOSTO","SEPTIEMBRE","OCTUBRE","NOVIEMBRE","DICIEMBRE"];
/////////////CONSULTAS/////////////////////
$periodo=date("Y");
$NmesA=(int)date("m");
//echo"select SUM(valor) as sumMes from  reg_pago where periodo=".$periodo." and mes=".$NmesA;
$SumaMes=mysqli_query($conexion,"select SUM(valor) as sumMes from  tbx_reg_pago where periodo=".$periodo." and mes=".$NmesA." and id_club=".$id_usu);
$filaSUM=mysqli_fetch_array($SumaMes, MYSQLI_ASSOC);
$SumaMes=(int)$filaSUM['sumMes'];
$subMes = new NumberFormatter( 'es_CO', NumberFormatter::CURRENCY );
$nomMes=$nMeses[$NmesA];
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
   
   
  </head>
  <body>
  <!-- Main content -->
  <section >
  <div class="row">
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title text-center text-success">Aporte Mensual</h5>
        <small><p class="card-text text-center text-primary"><? echo $nomMes;?></p></small>
        <p class="card-text text-center"><?echo $subMes->formatCurrency($SumaMes, "COP");?></p>
       
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h6 class="card-title text-center text-success">Gastos</h6>
        <small><p class="card-text text-center text-primary"><? echo $nomMes;?></p></small>
        <p class="card-text text-center">$ 500,000.</p>
       
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title text-center text-success">Inscripciones</h5>
        <small><p class="card-text text-center text-primary"><? echo $nomMes;?></p></small>
        <p class="card-text text-center">$ 1,000,000.</p>
       
      </div>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title text-center text-success">Otros Ingresos</h5>
        <small><p class="card-text text-center text-primary"><? echo $nomMes;?></p></small>
        <p class="card-text text-center">$ 1,500,000.</p>
       
      </div>
    </div>
  </div>
</div>

<br>







          
          






         
          <!-- Main row -->
          

          <div class='row'>
            <div class='col-md-3'>
              <!-- DIRECT CHAT -->
              <div class="card">
                <h6 class="card-header text-center  text-primary">Aporte Mensual <br><small>Detalle</small></h6>
              
                 <div class="card-body" style="height: 300px; overflow: auto; " >
                 
                  
                    <?php
                        include('../modDam/modFinan/ejec/ListPago.php');
                    ?>
                    <p></p>
               
                  <a href="#" class="btn btn-primary">Ver Informe</a>
                 </div>
               </div>
            </div>



            <div class='col-md-3'>
              <!-- DIRECT CHAT -->
              <div class="card">
              <h6 class="card-header text-center  text-primary">Gastos/Egresos <br><small>Detalle</small></h6>
              
              <div class="card-body" style="height: 300px; overflow: auto; " >
                 
                  
                    <?php
                        include('../modDam/mod_consultas/scrin/ListGastos.php');
                    ?>
                    <p></p>
               
                  <a href="#" class="btn btn-primary">Ver Informe</a>
                 </div>
               </div>
            </div>

            <div class='col-md-3'>
              <!-- DIRECT CHAT -->
              <div class="card">
              <h6 class="card-header text-center  text-primary">Inscripciones <br><small>Detalle</small></h6>
              
              <div class="card-body" style="height: 300px; overflow: auto; " >
                 
                  
                 <?php
                     include('../modDam/mod_consultas/scrin/ListInscripciones.php');
                 ?>
                 <p></p>
            
               <a href="#" class="btn btn-primary">Ver Informe</a>
                 </div>
               </div>
            </div>

            <div class='col-md-3'>
              <!-- DIRECT CHAT -->
              <div class="card">
              <h6 class="card-header text-center  text-primary">Otros Ingresos<br><small>Detalle</small></h6>
              
              <div class="card-body" style="height: 300px; overflow: auto; " >
                 
                  
                    <?php
                        include('../modDam/mod_consultas/scrin/ListVentas.php');
                    ?>
                    <p></p>
               
                  <a href="#" class="btn btn-primary">Ver Informe</a>
                 </div>
               </div>
            </div>
          </div><!-- /.row -->












        </section><!-- /.content -->






  </body>

 
</html>