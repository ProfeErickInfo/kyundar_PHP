<?php
$nimg=$_GET['nombreArch'];

?>
<input type="text"  name="Imgoculto" id="Imgoculto"    style="border:none; color:#FFF; background-color:#FFF" value="<? echo $nimg;?>"   />
