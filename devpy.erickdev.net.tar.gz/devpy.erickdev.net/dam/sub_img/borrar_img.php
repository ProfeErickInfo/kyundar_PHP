<?php
$nombreArch=$_GET['nombreArch'];
unlink("uploads/".$nombreArch);
?>
