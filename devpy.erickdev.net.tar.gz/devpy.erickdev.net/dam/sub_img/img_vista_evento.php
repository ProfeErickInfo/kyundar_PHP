<?php
$nimg=$_GET['nombreArch'];

?>
<img src='sub_img/uploads/<?=$nimg?>' alt='Ver $nimg'  height='150px' width='150px' style="alignment-adjust:auto">

