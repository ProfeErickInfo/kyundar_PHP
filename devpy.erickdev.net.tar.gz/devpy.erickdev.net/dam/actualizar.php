<!DOCTYPE html>
<html class="wide wow-animation" lang="es">
  <head>
    <title>Actualizar Datos-Bestuur</title>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!--------------------------
    Favicons
    ============================================= ----->
    <link rel="icon" href="../images/sj-icono144x144.png" type="image/x-icon">
   
	<link rel="stylesheet" href="../css/fonts.css">
	
    <link rel="stylesheet" href="../css/style.css">
	
    <link rel="stylesheet" href="ccss/font-awesome-4.7/css/font-awesome.min.css">
	<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js" integrity="sha384-SlE991lGASHoBfWbelyBPLsUlwY1GwNDJo3jSJO04KZ33K2bwfV9YBauFfnzvynJ" crossorigin="anonymous"></script>
	
    <!-- Bootstrap core CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<!----------------------------------------------------------------->
<!---------------Librerias-------------------------------->
<script src='libros/libDam.js' type='text/javascript'></script>
<script src='libros/validDam.js' type='text/javascript'></script>

<script type="text/javascript" src="libros/jquery.js"></script>

<!----Lib Finana----->
<!-------->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

<!----------------------------------------------------------------->
<link rel="stylesheet" href="ccss/css/main.css" />
		<noscript><link rel="stylesheet" href="ccss/css/noscript.css" /></noscript>
        
       

   <link href="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js">

<!----------------------------------------------------------------->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<!--------------------------------------------------->
<script> 
function ejecutaEventoOnclick(idUsu){ 

   //alert('si fue'+idUsu);
    if((idUsu==0)){
     location.href='../sesionOut.html';

    }
     
} 

function validar(e) {
  let tecla = (document.all) ? e.keyCode : e.which;
  if (tecla==13) alert ('Has pulsado enter');
}
</script>

<!---------------Librerias-------------------------------->
<script src='libros/libDam.js' type='text/javascript'></script>
<script src='libros/validDam.js' type='text/javascript'></script>
<script type="text/javascript" src="libros/js/jquery.js"></script>
<script type="text/javascript" src="libros/jquery.js"></script>
<script type="text/javascript" src="libros/jquery.watermarkinput.js"></script>
<!----Lib Finana----->
<script type="text/javascript" src="libros/libFinan/FunFinan.js"></script>
<!-------->
<script type="text/javascript" src="libros/jfind.js"></script>
<script type="text/javascript" src="libros/jlock.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

<!----------------------------------------------------------------->
 
<!----------------------fecha------------------------------->


<link rel="stylesheet" type="text/css" href="faces/datedropper.css"> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="libros/datedropper.js"></script>
<script>
$(document).ready(function(){
    $("#from").dateDropper();
});
</script>
<!-----------------------------------HOJAS DE ESTILO-------------------------------->



 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!----------------------------------------------------------------------------------->

  </head>
 <!--inicio barra de  menu -->
 
 <body>
 <div class="container-fluid">
 <nav class="navbar navbar-light bg-light fixed-top">


<b class="navbar-brand"  > <img src="../biblio10/images/SIKER2.png" alt="" width="143" height="35"/></b>

<div class="row">
      <div class="col"> 
      <input id="txtCodigo" class="form-control  me-2" type="number" placeholder="Codigo" >

      </div>
      <div class="col"> 
      <?php
      $Href = "JavaScript:cargarFocus('modDam/mod_registro/scrin/edit_afiliado.php?idDep='+document.getElementById('txtCodigo').value,'exeContent','carga','');";
		?>
      <span class="btn btn-outline-success" onclick="<?= $Href ?>" type="button ">Buscar</span>
      </div>
    </div>

</nav>
<div id="exeContent" style="padding-top: 20px; height: 700px; overflow : auto;">


</div>
<div class="col-auto"  style="align-content: end;"> <label></label>
        <div id="carga" style="visibility:hidden; position:relative; ">
           <img style="vertical-align:middle" src="imag/loadw.gif" alt="" width="40" height="40" />
        </div>
      </div>
</div>


 </body>
