<?php
echo"En vista...";
