<?PHP
@session_start(); 
$id_usu=(int)@$_SESSION['id_usuario'];
$Xrefer = getenv('HTTP_REFERER');
$url="/"; 


//if (!$ref || $ref != 'una_url.php')  
if (!$Xrefer) 
{  // Mostrar el error y redireccionar
	?>
     <meta http-equiv="Refresh" content="0; URL=<?Php $_SERVER ['SERVER_NAME'].$url; ?>/salida.html" />
     <?php
}  
else  
{  
    // Se ejecuta el ajax normalmente  
 
?>  
<?php 

include("../enlace/conexion.php");
if (!$conexion) {

		echo "La conexion no se pudo realizar, consulte con su administrador del sistema.";

		exit;

	}
//Gets the IP address
 $ip = getenv("REMOTE_ADDR") ;
 $idEvent=$_GET['idE'];
 $r=$_GET['r'];
          
 $_SESSION['idEvent']=$idEvent;
 $tipo=$_SESSION['tipo_U'];
 //echo "Your IP is " . $ip;  
 //tmpacceso
 $eyear=date("Y");
 $Revento=mysqli_query($conexion,"select * from trn_rel_evento  where idclub=".$id_usu."  and idevento=". $idEvent." and edicion=".$eyear );
 $siEsta=mysqli_fetch_array($Revento);
if($siEsta>0){
	$rx=1;

}else{
  	$eyear=date("Y");
	$Rgevento=mysqli_query($conexion,"insert into trn_rel_evento(idclub,idevento,edicion)values(".$id_usu." ,  ". $idEvent.", ".$eyear.")"  );
	if($Rgevento!=0){
		$rx=1;
	}else{
		echo"Se presento un error de registro, intentelo nuevamente";
		$rx=0;
		exit;
		
	}
	

}

?>
 <!--  
   Favicons
    =============================================
  
     -->
     <link rel="icon" type="image/png" sizes="144x144" href="../biblio10/images/favicons/sj-icono144x144.png">
  
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../biblio10/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../biblio10/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../biblio10/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../biblio10/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../biblio10/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../biblio10/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../biblio10/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../biblio10/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../biblio10/cssx/util.css">
	<link rel="stylesheet" type="text/css" href="../biblio10/cssx/main.css">
<!--===============================================================================================-->

 <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/floating-labels/">
<!---------- Bootstrap core CSS ------------>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="../biblio10/css/boots/floating-labels.css" rel="stylesheet">
<form class="form-signin" >
<div  class="text-center mb-8">
    
<!-----------<img class="img-fluid" alt="Responsive image" src="../biblio10/images/loading-37.gif" width=" x-small" height="x-small"   style="cursor:pointer; alignment-adjust:central"/> 
---->

<h1  class="h6"  >Descargando Información del evento...</h6>
  
  <p style="font:Verdana, Geneva, sans-serif; font-size:x-small; ">Si accede en 5 segundos, cancele y reinicie.</p>
  
 </div> 
 <button class="btn btn-primary btn-block" type="button" onclick="location.reload()" >
         <span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>
             CANCELAR
         </button>

  

</form>

<style type="text/css">
.info, .exito, .alerta, .error {
    font-family:Arial, Helvetica, sans-serif; 
    font-size:13px;
    border: 1px solid;
    margin: 10px 0px;
    padding:15px 10px 15px 50px;
    background-repeat: no-repeat;
    background-position: 10px center;
}
.error {
    color: #D8000C;
    background-color: #FFBABA;
    background-image: url('graficos/error.png');
}
</style>
<?PHP
//echo "R: ".$rx." Tipo: ".$tipo;
//$nom=mysqli_real_escape_string($conexion,$_POST['nom']);
//$pas=mysqli_real_escape_string($conexion,$_POST['pas']);

//$sqlDtsU=mysqli_query($conexion,"select * from tbz1_usu where nickz='".$nom."' and  pazz='".$pas."'");
//$cm=(int)mysqli_num_rows($sqlDtsU);
//$i=0; 
//$fila=mysqli_fetch_array($sqlDtsU, MYSQLI_NUM);
//echo "Datos; ".$cm." - ".$fila[6];
//if($cm==1 and $fila[6]==0 ){


				/*$i=1;
				$tipo=$fila[1];
				//echo"tipo: ".$fila[1];
				$id_asoc=$fila[2];
				/////////////////////////////////////////////////
				$sqlUsu=mysqli_query($conexion,"select * from tbx_club where id=".$id_asoc);
				//echo "select * from tbx_club where id=".$id_asoc;
				$filaU=mysqli_fetch_array($sqlUsu, MYSQLI_NUM);
				
				/////////////////////////////////////////////////
				$nombres=$filaU[1];
				//echo "N: ".$filaU[1];
				$logo=$filaU[10];
		
				$_SESSION['nombre_usu'] = $nombres;
				//@session_register('id_usuario');
				$_SESSION['id_usuario'] = $id_asoc;
				
				//echo"Asociado: ".$_SESSION['id_usuario'];
			    $_SESSION['img_foto'] = $logo;
				//@session_register('tipo_U');
				$_SESSION['tipo_U']=$tipo;
	            $minombre2=@$nombres;
				//echo  "Club: ".$minombre2;
                */
		   require_once ('../libMov/Mobile_Detect.php'); 
           //composer require mobiledetect/mobiledetectlib;
		  // echo "detecta: ".$detect;
		   $detect = new Mobile_Detect();
		  // echo "R: ".$r." Tipo: ".$tipo;   
 if ($detect->isMobile()==true) {

	if ($tipo==0){
		 if($r==0){   
		
			$url="indexApp.php"; 
			$_SESSION['direction']=$url;
		}elseif($r==5){   
		//echo "R: ".$r." Tipo: ".$tipo;
			$url="lstmedal.php"; 
			$_SESSION['direction']=$url;

	  }
	  ?><meta http-equiv="refresh" content="2; URL=<?Php $_SERVER ['SERVER_NAME'].$url; ?>movil.php" /><?php
		
	
	}elseif($tipo==2){
		if($r==1){   
			
			$url="invitado_app.php"; 
			$_SESSION['direction']=$url;
		
		}elseif($r==5){  
			//echo "R: ".$r." Tipo: ".$tipo;
			$url="lstmedal.php"; 
			$_SESSION['direction']=$url;

		  }
		  ?><meta http-equiv="refresh" content="2; URL=<?Php $_SERVER ['SERVER_NAME'].$url; ?>movil.php" /><?php
		
		}

  }else{
	
    	if ($tipo==0){
			if($r==0){   
				$url="index.php"; 
				$_SESSION['direction']=$url;
			  }elseif($r==5){   
				//echo "R: ".$r." Tipo: ".$tipo;
				$url="lstmedal.php"; 
				$_SESSION['direction']=$url;

			  }
			?>
			
       	<meta http-equiv="refresh" content="2; URL=<?Php $_SERVER ['SERVER_NAME'].$url; ?>desk.php" />
            <?php
			
			}elseif($tipo==1){
				if($r==0){   
					$url="club-in.php"; 
					$_SESSION['direction']=$url;
				  }elseif($r==5){   
					//echo "R: ".$r." Tipo: ".$tipo;  
					$url="lstmedal.php";  
					$_SESSION['direction']=$url;
	
				  }
				
			
			?>
			<meta http-equiv="refresh" content="2; URL=<?Php $_SERVER ['SERVER_NAME'].$url; ?>desk.php" />
       
	        <?php
			
			}else{
				if($r==1){   
					$url="invitado.php"; 
					$_SESSION['direction']=$url;
				  }elseif($r==5){ 
					//echo "R: ".$r." Tipo: ".$tipo;
					$url="lstmedal.php"; 
					$_SESSION['direction']=$url;
	
				  }
				
				
			?>
			<meta http-equiv="refresh" content="2; URL=<?Php $_SERVER ['SERVER_NAME'].$url; ?>desk.php" />
	   
            <?php
					//exit;	
				}
				
				/////////////////////////////////////////////////
	
	
    }
  

		}

?>
 