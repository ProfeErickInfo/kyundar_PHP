<?php
header('Cache-Control: no-store, no-cache, must-revalidate'); 
header('Pragma: no-cache');
@session_start(); 
$id_usu=(int)@$_SESSION['id_usuario'];
//echo "Usuario: ".$id_usu;
ob_end_clean();
header('Cache-Control: no-store, no-cache, must-revalidate'); header('Pragma: no-cache');
//$id_usu=4;
if($id_usu==0){
?> 
<script languaje="JavaScript">
location.href='../index.html';
</script>

<?php
}else{
    // Se ejecuta el ajax normalmente  
 
?>  
<?php 




	 include("../enlace/conexion.php");

	if (!$conexion) {

		echo "La conexion no se pudo realizar, consulte con su administrador del sistema.";

		//exit;

	}
/////////////////////////////////////////////////////
$mifoto=@$_SESSION['img_foto'];
$minombre2=$_SESSION['nombre_usu'];
  $CantMSG=19;
?>

<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="ccss/css/main.css" />
		<noscript><link rel="stylesheet" href="ccss/css/noscript.css" /></noscript>
        
         <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/floating-labels/">

   
<!-----------------aviso------------------->
<link rel="icon" type="image/png" href="imag/icon2.png" />
<title>TKD COLOSO</title>

<!-- Custom styles for this template -->
   
     <!-- Bootstrap core CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<!----------------------------------------------------------------->
<!---------------Librerias-------------------------------->
<script src='libros/libDam.js' type='text/javascript'/></script>
<script src='libros/validDam.js' type='text/javascript'/></script>

<script type="text/javascript" src="libros/jquery.js"></script>

<!----Lib Finana----->
<!-------->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

<!----------------------------------------------------------------->
<!-----------------------------------HOJAS DE ESTILO-------------------------------->
<link href="ccss/piel_dam.css" rel="stylesheet" type="text/css"/>
<!----------------------------------------------------------------------------------->
 <!---------------foto-------------------->
  
<script type="text/javascript" src="libros/jquery.min.js"></script>
<script type="text/javascript" src="libros/jquery.form.js"></script>

<script type="text/javascript" >
 $(document).ready(function() { 
		
            $('#photoimg').live('change', function()			{ 
			           $("#preview").html('');
			    $("#preview").html('<img src="sub_img/loader.gif" alt="Cargando...."/>');
			$("#imageform").ajaxForm({
						target: '#preview'
		}).submit();
				});
        }); 
</script>

<script type="text/javascript" >
 $(document).ready(function() { 
		
            $('#photoimg').live('change', function()			{ 
			           $("#nombreF").html('');
			    
			//$("#imageform").ajaxForm({
				//		target: '#nombreF'
		//}).submit();
		
			});
        }); 
</script>
<!--------------fin foto------------------->
<script>
function habilita() {
	// Accedemos al botón
var txtAcu = document.getElementById('txtAcudiente');
var txtDoc = document.getElementById('txtDocumento2');
var txtTipo = document.getElementById('TipoDocumento2');
// evento para el input radio del "no"
  txtAcu.disabled = false;
  txtTipo.disabled=false;
  txtDoc.disabled=false;
  txtAcu.value="";
  txtTipo.value="";
  txtDoc.value="";
  txtAcu.focus();
}
function nohabilita() {
	// Accedemos al botón
var txtAcu = document.getElementById('txtAcudiente');
var txtDoc = document.getElementById('txtDocumento2');
var txtTipo = document.getElementById('TipoDocumento2');

// evento para el input radio del "si"

  txtAcu.disabled = true;
  txtTipo.disabled=true;
  txtDoc.disabled=true;
  txtAcu.value="Yo Mismo";
  txtTipo.value=document.getElementById('TipoDocumento').value;
  txtDoc.value=document.getElementById('txtDocumento').value;
  document.getElementById('txtCelular').focus();



    
}
</script>
	</head>
	<body >
	


	<div class="card text-center">


		<div class="fixed-top" style="position:fixed; justify-content: center; top: 0vw; background-color:#F5F6FB; width:100%; height:7%; align-items:center; vertical-align: middle; text-center" >
   			 <? echo $minombre2;?>
   		</div>

		<div id="carga"></div>
          <div   id="DivContenido" style=" height:50%; width:auto;   padding-top:20vw; padding-bottom:20vw" >
                <?php include('modDam/mod_registro/scrin/Rdep.php');?>
          </div>
   </div>
   
  
                       
					
				

		<!-- Footer -->
		
		<div class="fixed-bottom" style="position: fixed; justify-content: center; bottom: 0vw; background-color:#F5F6FB; width:100%; ">
  
  <div class="card-footer text-muted" id="menu-bajo">

  <ul class="nav nav-pills">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" onClick="cargarFocus('modDam/mod_registro/scrin/Rdep.php','DivContenido','carga','TipoDocumento');">Atletas</a>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Inscripciones</a>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" onClick="cargarFocus('modDam/kombat/scrin/busca_dep.php','DivContenido','carga','TipoDocumento');">Combate</a></li>
      <li><a class="dropdown-item" href="#">Poomsae</a></li>
      <li><a class="dropdown-item" onClick="cargarFocus('modDam/infantes/scrin/busca_dep.php','DivContenido','carga','Grados');">Infantil</a></li>
      <li><hr class="dropdown-divider"></li>
      <li><a class="dropdown-item" onClick="cargarFocus('modDam/mod_consultas/Rpdf/scrin/busca_planilla.php','DivContenido','carga','');">Planillas</a></li>
    </ul>
  </li>
  <li class="nav-item">
    <a class="nav-link" onClick="cargarFocus('modDam/mod_registro/scrin/m_invitado.php?idClub=<?=$id_usu?>','DivContenido','carga','txtNomclub');">Yo</a>
  </li>fd
  <li class="nav-item">
    <a class="nav-link " onClick="if(confirm('Deseas cerrar la sesión actual?')){window.location='cerrarsesion.php';}" tabindex="-1" aria-disabled="true">Salir</a>
  </li>
</ul>

  </div>
  </div>

		<script>
			window.onload = function() { document.body.classList.remove('is-preload'); }
			window.ontouchmove = function() { return false; }
			window.onorientationchange = function() { document.body.scrollTop = 0; }




			
		</script>
        
	</body>
</html><?
}
?>