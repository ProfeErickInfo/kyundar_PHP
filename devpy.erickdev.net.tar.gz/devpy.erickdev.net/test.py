import subprocess
import sys
import os

def instalar_paquetes():
    try:
        import tweepy
        import dotenv
    except ImportError:
        print("Instalando dependencias necesarias (tweepy, python-dotenv)...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "tweepy", "python-dotenv"])
        print("Instalación completada. Continuando...\n")

# Instalar si hace falta
instalar_paquetes()

import tweepy
from dotenv import load_dotenv

# Cargar las variables del archivo .env
load_dotenv()

API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")
ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")
ACCESS_TOKEN_SECRET = os.getenv("ACCESS_TOKEN_SECRET")
BEARER_TOKEN = os.getenv("BEARER_TOKEN")

# Verificar que se cargaron correctamente
if not all([API_KEY, API_SECRET, ACCESS_TOKEN, ACCESS_TOKEN_SECRET, BEARER_TOKEN]):
    print("Error: una o mas claves de API no se encontraron en el archivo .env")
    print("Por favor revisa que el archivo .env esté en la misma carpeta y con los nombres correctos.")
    sys.exit(1)

# Probar conexión v1
def verificar_conexion_v1():
    try:
        print("Probando conexión con API v1.1 ...")
        auth = tweepy.OAuth1UserHandler(API_KEY, API_SECRET, ACCESS_TOKEN, ACCESS_TOKEN_SECRET)
        api = tweepy.API(auth)
        user = api.verify_credentials()
        if user:
            print(f"Conexión exitosa (API v1.1). Usuario autenticado: @{user.screen_name}")
        else:
            print("Error: no se pudo autenticar con API v1.1")
    except Exception as e:
        print("Error en la conexión (v1.1):", e)

# Probar conexión v2
def verificar_conexion_v2():
    try:
        print("Probando conexión con API v2 ...")
        client = tweepy.Client(bearer_token=BEARER_TOKEN, wait_on_rate_limit=True)
        user = client.get_user(username="DiscdDc")
        if user.data:
            print(f"Conexión exitosa (API v2). Usuario autenticado: @{user.data.username}")
        else:
            print("Error: no se pudo autenticar con API v2")
    except Exception as e:
        print("Error en la conexión (v2):", type(e).__name__, "-", e)


verificar_conexion_v1()
verificar_conexion_v2()